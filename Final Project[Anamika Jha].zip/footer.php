<?php
        include ("modal.php");
        ?>
        <div class="footer">
<footer>
    <link href="style.css" rel="stylesheet" type="text/css">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6"> 
              <h3>Information</h3>
                <p><a href="about.php"><span style="color:#868282;">About Us</span></a></p>
                <p><a href="contact.php"><span style="color:#868282;">Contact Us</span></a></p>
            </div>

            <div class="col-md-1">
         </div>
            <div class="col-md-3  col-sm-6">
              <h3>My Account</h3>
                <p><a href="login.php" data-toggle="modal" data-target="#loginmodal" ><span style="color:#868282;">Log In</span></a></p>
                <p><a href="signup.php"><span style="color:#868282;">Sign Up</span></a></p>
            </div>
             
            <div class="col-md-1">
           </div>
            <div class="col-md-3 col-sm-3">
              <a href="about.php"><span style="color:#868282;"><h3>Contact Us</h3></span></a>
                <p>CONTACT NO - +91 80007 90000</p>
                <a href="index1.php"><span style="color:#868282;">MobileStore.com</span></a> 
                
            </div>
        </div>
        
    </div>
</footer>
</div>